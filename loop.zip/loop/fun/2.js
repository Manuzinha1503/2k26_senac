

function dobro(a,b){
    return a*b;
}
n1 = 2;
n2 = 3;
let rr = dobro(n1,n2);
console.log(rr);